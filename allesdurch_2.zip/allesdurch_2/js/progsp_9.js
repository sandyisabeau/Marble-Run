Homeworks.aufgabe = 8;
// Benedikt Groß
// Example is based on examples from: http://brm.io/matter-js/, https://github.com/shiffman/p5-matter
// Benno Stäbler: kopiert vom 02-mouse Beispiel, erweitert um komplexe Bodies und in die bekannte Struktur gebracht
// Hier ist alles mit Classes codiert

let engine
let polySynth
let mouseConstraint
let ball
const Y_AXIS = 1;
const X_AXIS = 2;
// blocks are Block class instances/objects, which can react to balls and have attributes together with a Matter body
let blocks = []
// balls are just plain Matter bodys right now
let balls = []
// collisions are needed to save
let collisions = []
let layers = []
let domino
let isSmall = true;
let scaleFish = 0.07/2;
let sharkHit = 0;
let constraint5
let starHit = 0;
let jawHit= 0;
let magnet
let isMagnetisch = false
let sharkx = 250/2

function preload(){
    biteSound = loadSound("bite.mp3");
    failSound = loadSound("fail.mp3");
    airSound = loadSound("air.mp3");
    bubblesSound = loadSound("bubbles.mp3");
    boingSound = loadSound("boing.mp3");
    spinSound = loadSound("spin.mp3");
    jawsSound = loadSound("jaws.mp3");
}

class Block {
  constructor(type, attrs, options) {
    this.type = type
    this.attrs = attrs
    this.options = options
    this.hit = false
    this.options.plugin = { block: this, update: this.update }
    switch (this.type) {
      case 'rect':
        this.body = Matter.Bodies.rectangle(attrs.x, attrs.y, attrs.w, attrs.h, this.options)
        break
      case 'circle':
        this.body = Matter.Bodies.circle(attrs.x, attrs.y, attrs.s)
        break
      case 'points':
        let shape = Matter.Vertices.create(attrs.points, Matter.Body.create({}))
        this.body = Matter.Bodies.fromVertices(0, 0, shape, this.options)
        Matter.Body.setPosition(this.body, this.attrs)
        break
        case 'path':
          let path = document.getElementById(attrs.elem)
          if (null != path) {
            this.body = Matter.Bodies.fromVertices(0, 0, Matter.Vertices.scale(Matter.Svg.pathToVertices(path, 10), this.attrs.scale, this.attrs.scale), this.options)
            Matter.Body.setPosition(this.body, this.attrs)
          }
          break
    }
    Matter.World.add(engine.world, [this.body])
  }

  constrainTo(block) {
    let constraint
    if (block) {
      constraint = Matter.Constraint.create({
        bodyA: this.body,
        bodyB: block.body
      })
    } else {
      constraint = Matter.Constraint.create({
        bodyA: this.body,
        pointB: { x: this.body.position.x, y: this.body.position.y }
      })
    }
    Matter.World.add(engine.world, [constraint])
    constraints.push(constraint)
  }

  update(ball) {
      // polySynth.play('C4', 0.1, 0, 0.3);


      if (this.attrs.force) {
        Matter.Body.applyForce(ball, ball.position, this.attrs.force)
      }

if (this.attrs.isJellyfish){
  boingSound.play();
}
if (this.attrs.isStar){
if (starHit ==0){
  isMagnetisch = true;
  spinSound.play();
  Matter.Body.applyForce(blocks[20].body, {x: blocks[20].body.position.x,y:blocks[20].body.position.y-100} , {x:-3/2,y:0});

starHit++;

setTimeout(starLetGo,3000);
}
}



      if ((!this.hit && this.attrs.chgStatic)&&(this.body.isStatic = true)) {
           Matter.Body.setStatic(this.body, false)
         }
      if (this.body.angle >= PI/4 && this.attrs.chgStatic) {
           Matter.Body.setStatic(this.body, true)

         }
         if (this.attrs.isPortal ){
           sharkHit = 0;
           jawHit = 0;
           starHit = 0;
             setTimeout(restart,100);
             Matter.Body.setStatic(ball, true);
             setTimeout(awake, 1000)
            }
         this.hit = true
}
  show() {
    fill(this.attrs.color)
    drawBody(this.body)
  }
}
function restart() {
  failSound.play();
  Matter.Body.setPosition(ball, {x:100/2, y:60/2});

}
function awake(){
  Matter.Body.setStatic(ball, false)
}
function setup() {

airSound.setVolume(0.7);
biteSound.setVolume(0.5);
bubblesSound.setVolume(0.5);
boingSound.setVolume(0.5);
spinSound.setVolume(0.5);
jawsSound.setVolume(0.5);




  // enable sound
  polySynth = new p5.PolySynth()
  let canvas = createCanvas(windowWidth, 4100/2)

//ball Bild
   ballImg = loadImage('ball.png');
   pearlImg = loadImage('pearl.png');
// blurryview Bild
  viewImg = loadImage("view.png");
  backgroundImg = loadImage("background.png")
  // teeth Bild
  lowerteethImg = loadImage("lowerteeth.png")
  upperteethImg = loadImage("upperteeth.png")
  //shark Bild
  sharkleftImg = loadImage("sharkleft.png")
  sharkrightImg = loadImage("sharkright.png")

  crabImg = loadImage("crab.png")
  bubblesGif = loadImage("bubbles.gif")




  // create an engine
  engine = Matter.Engine.create()
//aufzug1
  /*0*/ blocks.push(new Block('rect',{ x: 120/2, y: 650/2 , w: 20/2, h: 75/2, color: color(0,255,255,0) }, { isStatic: true}))
  /*1*/ blocks.push(new Block('rect',{ x: 320/2, y: 650/2 , w: 20/2, h: 75/2, color: color(0,255,255,0) }, { isStatic: true}))
  /*2*/ blocks.push(new Block('rect',{ x: 170/2, y: 705/2 , w: 200/2, h: 20/2, color: color(0,255,255,0) }, { isStatic: true}))

// blöcke ganz oben
  /*3*/ blocks.push(new Block('rect',{ x: 150/2 , y: 95/2 , w: 250/2, h: 22/2, color: color(101,51,16) }, { isStatic: true, angle: PI/32, friction: 0.5 }))
  /*4*/ blocks.push(new Block('rect',{ x: 427/2 , y: 120/2 , w: 90/2, h: 22/2, color: color(101,51,16) }, { isStatic: true, angle: PI/32, friction: 0.5 }))
//dominos
  /*5*/ blocks.push(new Block('rect',{ x: 290/2, y: 50/2 , w: 22/2, h: 100/2, color: color(101, 51, 16), chgStatic: true }, { isStatic: true, angle: PI/32, friction: 0}))
  /*6*/ blocks.push(new Block('rect',{ x: 490/2 , y: 66/2 , w: 22/2, h: 100/2, color: color(101, 51, 16), chgStatic: true }, { isStatic: true, angle: PI/32, friction: 0}))
  /*7*/ blocks.push(new Block('rect',{ x: 690/2 , y: 84/2 , w: 22/2, h: 100/2, color: color(101, 51, 16), chgStatic: true}, { isStatic: true, angle: PI/32, friction: 0}))

  //obere schwarze blöcke
  /*8*/ blocks.push(new Block('rect',{ x: 633/2 , y: 141/2 , w: 90/2, h: 22/2, color: color(101, 51, 16) }, { isStatic: true, angle: PI/32, friction: 0.5 }))

  /*9*/ blocks.push(new Block('rect',{ x: 700/2, y: 380/2, w: 870/2, h: 35/2, color: color(101, 51, 16) }, { isStatic: true, angle: -PI/64, friction: 0}))
  /*10*/ blocks.push(new Block('rect',{ x: 380/2 , y: 136/2 , w: 580/2, h: 20/2, color: color(255,255,255,0) }, { isStatic: true, angle: PI/32, friction: 0 }))
  /*11*/ blocks.push(new Block('rect',{ x: 380/2, y: 440/2, w: 30/2, h: 0/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))
  // blocks.push(new Block('rect',{ x: 1050, y: 420, w: 30, h: 200, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))
  /*12*/ blocks.push(new Block('rect',{ x: 40/2, y: 220/2, w: 30/2, h: 80/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))

// zähne
  let pts1 = [{ x: 0, y: 0 }, { x: 900/2, y: 0 }, { x: 900/2, y: 100/2 }, { x: 600/2, y: 40/2 }, { x: 600/2, y: 100/2 }, { x: 300/2, y: 40/2 }, { x: 300/2, y: 100/2 }, { x: 1/2, y: 40/2 }]
  let pts2 = [{ x: 0, y: 0 }, { x: 300/2, y: -100/2 }, { x: 300/2, y: -40/2 }, { x: 600/2, y: -100/2 }, { x: 600/2, y: -40/2 }, { x: 900/2, y: -100/2 }, { x: 900/2, y: -40/2 }, { x: 0, y: 0 }]
  /*13*/ blocks.push(new Block('points', { x: 500/2, y: 900/2, points: pts1, color:"transparent" }, { isStatic: true}))
  /*14*/ blocks.push(new Block('points', { x: 700/2, y: 1100/2, points: pts2, color: "transparent" }, { isStatic: true}))
  /*15*/ blocks.push(new Block('rect',{ x: 40/2, y: 1010/2, w: 30/2, h: 290/2, color: color(98,170,29) }, { isStatic: true, friction: 0}))
  /*16*/ blocks.push(new Block('rect',{ x: 240/2, y:1100/2, w: 30/2, h: 100/2, color: "transparent" }, { isStatic: true, friction: 0}))
// block links neben quallen
  /*17*/ blocks.push(new Block('rect',{ x: 140/2, y:1350/2, w: 300/2, h: 35/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0, angle: PI/32}))
// quallen
  /*18*/ blocks.push(new Block('path', { x: 350/2, y: 1500/2, elem: 'jellyfish', scale: 0.6/2, color: 'violet', force: { x: 0.0, y: -1.0 }, isJellyfish: true }, { isStatic: true, friction: 0.001, restitution: 0.5}))
  /*19*/ blocks.push(new Block('path', { x: 480/2, y: 1700/2, elem: 'jellyfish', scale: 0.6/2, color: 'violet', force: { x: 0.0, y: -1.0 }, isJellyfish: true }, { isStatic: true, friction: 0.001, restitution: 0.5}))
// stern
 /*20*/ blocks.push(new Block('path', { x: 710/2, y: 1900/2, elem: 'star', scale: 0.6/2, color: 'orange' , isStar: true}, { isStatic: false}))
// blöcke unterm stern
  /*21*/ blocks.push(new Block('rect',{ x: 750/2, y: 2350/2, w: 700/2, h: 35/2, color: color(101, 51, 16) }, { isStatic: true, angle: -PI/64, friction: 0}))
// blocks.push(new Block('rect',{ x: 400, y: 2340, w: 30, h: 80, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))
// blocks.push(new Block('rect',{ x: 1000, y: 2270, w: 30, h: 200, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))

  /*22*/ blocks.push(new Block('rect',{ x: 220/2, y: 2100/2, w: 600/2, h: 35/2, color: color(101, 51, 16) }, { isStatic: true, angle: PI/32, friction: 0}))
  /*23*/ blocks.push(new Block('rect',{ x: 5/2, y: 2100/2, w: 25/2, h: 80/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))
// blocks.push(new Block('rect',{ x: 500, y: 2170, w: 30, h: 80, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))
// aufzug 2
  /*24*/ blocks.push(new Block('rect',{ x: 120/2, y: 2550/2 , w: 20/2, h: 75/2, color:color(0,255,255,0) }, { isStatic: true}))
  /*25*/ blocks.push(new Block('rect',{ x: 320/2, y: 2550/2 , w: 20/2, h: 75/2, color:color(0,255,255,0) }, { isStatic: true}))
  /*26*/ blocks.push(new Block('rect',{ x: 170/2, y: 2605/2 , w: 200/2, h: 20/2, color:color(0,255,255,0) }, { isStatic: true}))
// rutsche
  /*27*/ blocks.push(new Block('path', { x: 820/2, y: 3100/2, elem: 'rutsche', scale: 2.5/2, color: 'green' }, { isStatic: true, friction: 0.1 }))
// blocks.push(new Block('rect',{ x: 720, y: 3300 , w: 1500, h: 50, color: "green" }, { isStatic: true, angle: -PI/4}))
// blöcke beim hai
  /*28*/ blocks.push(new Block('rect',{ x: 140/2, y:3950/2, w: 300/2, h:35/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0, angle: PI/32}))
  /*29*/ blocks.push(new Block('rect',{ x: 10/2, y:3820/2, w: 30/2, h: 550/2, color: color(255,255,255,0) }, { isStatic: true, friction: 0, angle: PI/32}))

  /*30*/ blocks.push(new Block('rect',{ x: 1240/2, y:4000/2, w: 600/2, h: 35/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0, angle: PI/32}))
// blocks.push(new Block('rect',{ x: 810, y:3920, w: 30, h: 350, color: color(101, 51, 16) }, { isStatic: true, friction: 0, angle: PI/32}))
// neuer block ganz oben
  /*31*/ blocks.push(new Block('rect',{ x: 930/2 , y: 165/2 , w: 250/2, h: 22/2, color: color(101, 51, 16) }, { isStatic: true, angle: PI/32, friction: 0.5 }))
  /*32*/ blocks.push(new Block('rect',{ x: 275/2 , y: 195/2 , w: 500/2, h: 35/2, color: color(101, 51, 16) }, { isStatic: true, angle: PI/32, friction: 0.5 }))
// portal oben
  /*33*/ blocks.push(new Block('rect',{ x: 225/2 , y: 700/2 , w: 400/2, h: 20/2, color: color(255,255,255,0), isPortal: true}, { isStatic: true, restitution: 0}))
// portal unten
  /*34*/ blocks.push(new Block('rect',{ x: 225/2 , y: 2680/2 , w: 400/2, h: 20/2, color: color(255,255,255,0), isPortal: true }, { isStatic: true, restitution: 0}))
  // stop oben
   /*35*/ blocks.push(new Block('rect',{ x: 280/2, y: 370/2, w: 30/2, h: 75/2, color: color(101, 51, 16) }, { isStatic: true, friction: 0}))


    domino = blocks[5].body;
      constraint = Matter.Constraint.create({
        bodyA: domino,
        pointA: {x: -10/2, y: 50/2} ,
        pointB: {x: domino.position.x-(11/2), y: domino.position.y+(50/2)} ,
    });

Matter.World.add(engine.world, [constraint]);

    domino2 = blocks[6].body;
      constraint2 = Matter.Constraint.create({
        bodyA: domino2,
        pointA: {x: -10/2, y: 50/2} ,
        pointB: {x: domino2.position.x-11/2, y: domino2.position.y+50/2} ,
    });

Matter.World.add(engine.world, [constraint2]);

    domino3 = blocks[7].body;
      constraint3 = Matter.Constraint.create({
        bodyA: domino3,
        pointA: {x: -10/2, y: 50/2} ,
        pointB: {x: domino3.position.x-11/2, y: domino3.position.y+50/2} ,
    });

Matter.World.add(engine.world, [constraint3]);

star = blocks[20].body;
      constraint4 = Matter.Constraint.create({
        bodyA: star,
        pointB: {x: star.position.x, y: star.position.y},
    });

Matter.World.add(engine.world, [constraint4]);


  // setup mouse
  let mouse = Matter.Mouse.create(canvas.elt)
  let mouseParams = {
    mouse: mouse,
    constraint: { stiffness: 0.05, angularStiffness: 0 }
  }
  mouseConstraint = Matter.MouseConstraint.create(engine, mouseParams)
  mouseConstraint.mouse.pixelRatio = pixelDensity()
  Matter.World.add(engine.world, mouseConstraint)

  // create ball

  ball = Matter.Bodies.circle(100/2, 50/2, 22.4/2, {
      restitution: 0.1,
      density: 0.05,
      friction: 0
    })
    Matter.World.add(engine.world, ball)
    balls.push(ball)



  // Process collisions - check whether ball hits a Block object
  Matter.Events.on(engine, 'collisionStart', function(event) {
    var pairs = event.pairs
    pairs.forEach((pair, i) => {
      if (balls.includes(pair.bodyA)) {
        collide(pair.bodyB, pair.bodyA)

      }
      if (balls.includes(pair.bodyB)) {
        collide(pair.bodyA, pair.bodyB)
      }
    })
    // check for collision between Block and ball
    function collide(bodyBlock, bodyBall) {
      // check if bodyBlock is really a body in a Block class
      if (bodyBlock.plugin && bodyBlock.plugin.block) {
        // remember the collision for processing in 'beforeUpdate'
        collisions.push({ hit: bodyBlock.plugin.block, ball: bodyBall })
        console.log('hit')
        console.log(domino.position.x)

      }
    }
  })

  Matter.Events.on(engine, 'beforeUpdate', function(event) {
    // process collisions at the right time
    collisions.forEach((collision, i) => {
      // "inform" blocks: got hit by a ball
      collision.hit.update(collision.ball)
    });
    collisions = []
    balls.forEach((ball, i) => {
      attract(ball)

   });
  })

  // double the gravity
  // engine.world.gravity.y = 2
  // run the engine automatically
  // Matter.Engine.run(engine)
  // start the engine on mouse click
  canvas.mousePressed(startEngine);

  document.addEventListener('keyup', onKeyUp)
}

function onKeyUp(evt) {
  switch (evt.key) {
    case ' ':
      startEngine()
      evt.preventDefault()
      break
  }
}

function startEngine() {
  if (0 == engine.timing.timestamp) {
    Matter.Engine.run(engine)
    userStartAudio()
  }
}

function draw() {
  //hintergrund
    image(backgroundImg,0,0,windowWidth,4100);

    //bubbles
    image(bubblesGif,-10/2,250/2,350/2,300/2);
    image(bubblesGif,600/2,450/2,350/2,300/2);
    image(bubblesGif,-40/2,1070/2,350/2,300/2);
    image(bubblesGif,-20/2,1700/2,350/2,300/2);
    image(bubblesGif,-20/2,2700/2,350/2,300/2);
    image(bubblesGif,600/2,1300/2,350/2,300/2);





// setGradient(0, 0, windowWidth, 5000, color(0,153,153), color(0,51,102), Y_AXIS);

   noStroke();
scrollFollow(ball);
drawSprite(ball, ballImg,scaleFish);




//aufzug 1 bewegung
    Matter.Body.setPosition(blocks[0].body, {x: 320/2 +Math.sin(frameCount/40)* 300/2, y: 570/2})
    Matter.Body.setPosition(blocks[1].body, {x: 520/2 +Math.sin(frameCount/40)* 300/2, y: 570/2})
    Matter.Body.setPosition(blocks[2].body, {x: 420/2 +Math.sin(frameCount/40)* 300/2, y: 610/2})

  blocks.forEach(block => block.show())

//aufzug 2 bewegung
    Matter.Body.setPosition(blocks[24].body, {x: 300/2 +Math.sin(frameCount/40)* 300/2, y: 2550/2})
    Matter.Body.setPosition(blocks[25].body, {x: 500/2 +Math.sin(frameCount/40)* 300/2, y: 2550/2})
    Matter.Body.setPosition(blocks[26].body, {x: 400/2 +Math.sin(frameCount/40)* 300/2, y: 2590/2})


    //zähne bewegung
      Matter.Body.setPosition(blocks[13].body, {x: 500/2, y: 900/2 + Math.abs(Math.sin(frameCount/40)* 100/2)});

  push();
  noFill();
  balls.forEach(ball => drawBody(ball))
  pop();


// ball wird von hai gefressen
if ((ball.position.x > 250/2 && ball.position.y > 3900/2)&&(ball.position.x < 300/2 && ball.position.y < 4000/2)){
  Matter.Body.setPosition(ball, {x:250/2, y:3900/2});
  scaleFish = 0
  sharkleftImg = sharkrightImg;
  ballImg=pearlImg;
  while (sharkx<600/2) { sharkx += 20/2;}
  sharkHit = sharkHit+1
  if (sharkHit ==1){
  biteSound.play();
  jawsSound.stop();
}
  setTimeout(sharkEat,100)
}

function sharkEat(){
Matter.Body.setPosition(ball, {x:1000/2, y:3910/2});
  scaleFish =0.07;
}


  stroke('green')
  engine.world.constraints.forEach((constraint, i) => {
    if (constraint.label == "Mouse Constraint") {
      drawMouse(mouseConstraint)
    } else {
      drawConstraint(constraint)
    }
  })

image(lowerteethImg,-20/2, 765/2,1200/2,800/2);
image(sharkleftImg,sharkx,3750/2,300/2,225/2);
image(upperteethImg,blocks[13].body.position.x-500/2,blocks[13].body.position.y-370/2,1200/2,900/2);
image(crabImg,blocks[1].body.position.x-270/2,blocks[1].body.position.y-70/2,350/2,250/2);
image(crabImg,blocks[25].body.position.x-270/2,blocks[25].body.position.y-70/2,350/2,250/2);

push();
imageMode(CENTER);
image(viewImg,ball.position.x,ball.position.y);
pop();

if (ball.position.y > 2620/2){
  jawHit++
  if (jawHit==1){
  jawsSound.play();}
}


}

function drawMouse(mouseConstraint) {
  if (mouseConstraint.body) {
    let pos = mouseConstraint.body.position
    let offset = mouseConstraint.constraint.pointB
    let m = mouseConstraint.mouse.position
    stroke(0, 255, 0)
    strokeWeight(2)
    line(pos.x + offset.x, pos.y + offset.y, m.x, m.y)
  }
}

function drawConstraint(constraint) {
  let posA = { x: 0, y: 0 }
  if (constraint.bodyA) {
    posA = constraint.bodyA.position
  }
  let posB = { x: 0, y: 0 }
  if (constraint.bodyB) {
    posB = constraint.bodyB.position
  }
  line(
    posA.x + constraint.pointA.x,
    posA.y + constraint.pointA.y,
    posB.x + constraint.pointB.x,
    posB.y + constraint.pointB.y
  )
}

function drawBody(body) {
  if (body.parts && body.parts.length > 1) {
    body.parts.filter((part, i) => i > 0).forEach((part, i) => {
      drawVertices(part.vertices)
    })
  } else {
    if (body.type == "composite") {
      body.bodies.forEach((body, i) => {
        drawVertices(body.vertices)
      })
    } else {
      drawVertices(body.vertices)
    }
  }
}

function drawVertices(vertices) {
  beginShape()
  vertices.forEach((vert, i) => {
    vertex(vert.x, vert.y)
  })
  endShape(CLOSE)
}



function keyPressed(){
  switch (keyCode) {
// Taste C
    case 67:
  engine.world.gravity.y = -engine.world.gravity.y;
  if (engine.world.gravity.y < 0){
    airSound.play()
  }
  if (engine.world.gravity.y > 0){
    bubblesSound.play()
  }


  if (isSmall) {
       Matter.Body.scale(balls[0], 1.5, 1.5);
       scaleFish=(0.07/2*1.5);
     } else {
       Matter.Body.scale(balls[0], 0.66666666666, 0.66666666666);
       scaleFish=(0.07/2);
     }
     isSmall = !isSmall; // toggle isSmall variable
   }
    }

    function scrollFollow(matterObj) {
      if (insideViewport(matterObj) == false) {
        const $element = $('html, body');
        if ($element.is(':animated') == false) {
          $element.animate({
            scrollLeft: ball.position.x,
            scrollTop: ball.position.y-windowHeight/3/2
          }, 1000);
        }
      }
    }

    function insideViewport(matterObj) {
  const x = matterObj.position.x;
  const y = matterObj.position.y+200/2;
  const pageXOffset = window.pageXOffset || document.documentElement.scrollLeft;
  const pageYOffset  = window.pageYOffset || document.documentElement.scrollTop;
  if (x >= pageXOffset && x <= pageXOffset + windowWidth &&
      y >= pageYOffset && y <= pageYOffset + windowHeight) {
    return true;
  } else {
    return false;
  }
}



function drawSprite(body, img,scaleSprite) {
  const pos = body.position;
  const angle = body.angle;
  const size = body.circleRadius
  push();
  translate(pos.x, pos.y);
  rotate(angle);
  scale(scaleSprite);
  imageMode(CENTER);
  image(img, 0, 0);
  pop();
}

function attract(ball) {
   magnet = blocks[20].body;
   if (isMagnetisch) {
     let force = {
       x: (magnet.position.x - ball.position.x) * 0.005,
       y: (magnet.position.y - ball.position.y) * 0.005,
     }
     console.log(force)
     //Matter.Body.applyForce(ball, ball.position, Matter.Vector.neg(force));
     Matter.Body.applyForce(ball, ball.position, force)
   }
 }

  function starLetGo(){
    magnet = blocks[21].body;
    setTimeout(starLetGotwo,3000);}
  function starLetGotwo(){

    isMagnetisch = false;}
