# Programming with Javascript #

This folder contains data files to be processed by our javascript programs
For the Homeworks javascript library here is the place for the student.id file
